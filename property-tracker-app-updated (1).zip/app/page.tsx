import { useState } from "react";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";

export default function PropertyTrackerApp() {
  const [deals, setDeals] = useState([
    {
      name: "Example 1",
      type: "Flip",
      purchase: 1400000,
      renovation: 250000,
      other: 100000,
      investment: 1750000,
      arv: 2275000,
      target: 2275000,
      status: "Renovation",
      profit: 525000,
      cashFlow: 0,
    },
    {
      name: "Example 2",
      type: "Rental",
      purchase: 1800000,
      renovation: 150000,
      other: 50000,
      investment: 2000000,
      arv: 0,
      target: 0,
      status: "Rented",
      profit: null,
      cashFlow: 18000,
    },
    {
      name: "Example 3",
      type: "Financing",
      purchase: 1600000,
      renovation: 0,
      other: 30000,
      investment: 1630000,
      arv: 0,
      target: 53200,
      status: "Paying",
      profit: null,
      cashFlow: 53200,
    },
  ]);

  const [newDeal, setNewDeal] = useState({
    name: "",
    type: "",
    purchase: 0,
    renovation: 0,
    other: 0,
    status: "",
  });

  const calculateDealFields = (deal) => {
    const investment = deal.purchase + deal.renovation + deal.other;
    let target = 0;
    let profit = 0;
    let cashFlow = 0;
    let arv = 0;

    if (deal.type.toLowerCase() === "flip") {
      arv = investment * 1.3;
      target = arv;
      profit = target - investment;
    } else if (deal.type.toLowerCase() === "rental") {
      cashFlow = Math.floor(0.75 * 0.01 * investment);
    } else if (deal.type.toLowerCase() === "financing") {
      cashFlow = Math.floor(0.015 * investment);
    }

    return {
      ...deal,
      investment,
      arv,
      target,
      profit: deal.type.toLowerCase() === "flip" ? profit : null,
      cashFlow,
    };
  };

  const addDeal = () => {
    const completeDeal = calculateDealFields(newDeal);
    const updatedDeals = [...deals, completeDeal];
    setDeals(updatedDeals);
    setNewDeal({
      name: "",
      type: "",
      purchase: 0,
      renovation: 0,
      other: 0,
      status: "",
    });
  };

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Property Deal Tracker</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {deals.map((deal, index) => (
          <Card key={index}>
            <CardContent className="p-4 space-y-2">
              <p><strong>{deal.name}</strong> ({deal.type})</p>
              <p>Purchase: ₱{deal.purchase.toLocaleString()}</p>
              <p>Renovation: ₱{deal.renovation.toLocaleString()}</p>
              <p>Other Costs: ₱{deal.other.toLocaleString()}</p>
              <p>Total Investment: ₱{deal.investment.toLocaleString()}</p>
              <p>After Renovation Value (ARV): ₱{deal.arv ? deal.arv.toLocaleString() : '-'}</p>
              <p>Target: ₱{deal.target.toLocaleString()}</p>
              <p>Status: {deal.status}</p>
              <p>Profit: ₱{deal.profit ? deal.profit.toLocaleString() : '-'}</p>
              <p>Cash Flow: ₱{deal.cashFlow.toLocaleString()}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="space-y-2">
        <h2 className="text-xl font-semibold">Add New Deal</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <Input placeholder="Name" value={newDeal.name} onChange={(e) => setNewDeal({ ...newDeal, name: e.target.value })} />
          <Select onValueChange={(value) => setNewDeal({ ...newDeal, type: value })}>
            <SelectTrigger><SelectValue placeholder="Select Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Flip">Flip</SelectItem>
              <SelectItem value="Rental">Rental</SelectItem>
              <SelectItem value="Financing">Financing</SelectItem>
            </SelectContent>
          </Select>
          <Input placeholder="Purchase Price" type="number" value={newDeal.purchase} onChange={(e) => setNewDeal({ ...newDeal, purchase: Number(e.target.value) })} />
          <Input placeholder="Renovation Cost" type="number" value={newDeal.renovation} onChange={(e) => setNewDeal({ ...newDeal, renovation: Number(e.target.value) })} />
          <Input placeholder="Other Costs" type="number" value={newDeal.other} onChange={(e) => setNewDeal({ ...newDeal, other: Number(e.target.value) })} />
          <Select onValueChange={(value) => setNewDeal({ ...newDeal, status: value })}>
            <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="New">New</SelectItem>
              <SelectItem value="Renovation">Renovation</SelectItem>
              <SelectItem value="Rented">Rented</SelectItem>
              <SelectItem value="Paying">Paying</SelectItem>
              <SelectItem value="Sold">Sold</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button className="mt-2" onClick={addDeal}>Add Deal</Button>
      </div>
    </div>
  );
}
